package com.example.Orders.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VendorDTO {
    private Integer id;
    private String name;
    private String contactEmail;
}
