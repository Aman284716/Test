//package com.example.Orders.service;
//
//import com.example.Orders.dto.OrdersDTO;
//import com.example.Orders.model.Orders;
//import com.example.Orders.repository.OrdersRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import reactor.core.publisher.Flux;
//import reactor.core.publisher.Mono;
//
//@Service
//public class OrdersService {
//
//    @Autowired
//    private OrdersRepository ordersRepository;
//
//    @Autowired
//    private SequenceService sequenceService;
//
//    public Mono<Orders> createOrder(Orders order) {
//        return sequenceService.getNextSequence("orders_sequence")
//                .map(seq -> {
//                    order.setId(seq);
//                    return order;
//                })
//                .flatMap(ordersRepository::save);
//    }
//
//    public Mono<Orders> getOrderById(Integer id) {
//        return ordersRepository.findById(id);
//    }
//
//    public Mono<Orders> updateOrder(Integer id, Orders order) {
//        order.setId(id);
//        return ordersRepository.save(order);
//    }
//
//    public Mono<Void> deleteOrder(Integer id) {
//        return ordersRepository.deleteById(id);
//    }
//
//    public Flux<Orders> getOrdersByCustomerId(Integer customerId) {
//        return ordersRepository.findByCustomerId(customerId);
//    }
//}

package com.example.Orders.service;

import com.example.Orders.dto.CustomerDTO;
import com.example.Orders.dto.VendorDTO;
import com.example.Orders.model.Orders;
import com.example.Orders.repository.OrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrdersService {

    public Mono<Orders> createOrder(Orders order) {
        return sequenceService.getNextSequence("orders_sequence")
                .map(seq -> {
                    order.setId(seq);
                    return order;
                })
                .flatMap(ordersRepository::save)
                .flatMap(savedOrder -> sendEmailsAfterOrderCreation(savedOrder)
                        .thenReturn(savedOrder));
    }

    public Flux<Orders> createSplitOrders(Orders order) {
        // Split items by vendorId without blocking
        return Flux.fromIterable(order.getItems())
                .groupBy(Orders.OrderItem::getVendorId)
                .flatMap(group ->
                        group.collectList()
                                .map(items -> {
                                    Orders vendorOrder = new Orders();
                                    vendorOrder.setCustomerId(order.getCustomerId());
                                    vendorOrder.setOrderDate(order.getOrderDate());
                                    vendorOrder.setShippingAddress(order.getShippingAddress());
                                    vendorOrder.setItems(items);
                                    return vendorOrder;
                                })
                                .flatMap(this::createOrder)
                );
    }

    public Mono<Orders> getOrderById(Integer id) {
        return ordersRepository.findById(id);
    }

    public Mono<Orders> updateOrder(Integer id, Orders order) {
        order.setId(id);
        return ordersRepository.save(order);
    }

    public Mono<Void> deleteOrder(Integer id) {
        return ordersRepository.deleteById(id);
    }

    public Flux<Orders> getOrdersByCustomerId(Integer customerId) {
        return ordersRepository.findByCustomerId(customerId);
    }

    public Mono<Void> deleteOrdersByProductId(Integer productId) {
        return ordersRepository.findByItemsProductId(productId) // Fetch orders with the product ID
                .flatMap(ordersRepository::delete) // Delete each order
                .then();
    }

    public Mono<Void> deleteOrdersByVendorId(Integer vendorId) {
        return ordersRepository.findByItemsVendorId(vendorId)
                .flatMap(order -> ordersRepository.deleteById(order.getId()))
                .then();
    }


    public Mono<Void> deleteOrdersByCustomerId(Integer customerId) {
        return ordersRepository.findByCustomerId(customerId)
                .flatMap(ordersRepository::delete)
                .then();
    }



    private final OrdersRepository ordersRepository;
    private final SequenceService sequenceService;
    private final EmailService emailService;
    private final WebClient customerClient;
    private final WebClient vendorClient;

    @Autowired
    public OrdersService(OrdersRepository ordersRepository, SequenceService sequenceService,
                         EmailService emailService, WebClient.Builder webClientBuilder) {
        this.ordersRepository = ordersRepository;
        this.sequenceService = sequenceService;
        this.emailService = emailService;
        this.customerClient = webClientBuilder.baseUrl("http://localhost:8081").build();
        this.vendorClient = webClientBuilder.baseUrl("http://localhost:8084").build();
    }

    private Mono<Void> sendEmailsAfterOrderCreation(Orders order) {
        System.out.println("Preparing to send emails for order: " + order.getId());

        Mono<CustomerDTO> customerMono = customerClient.get()
                .uri("/customers/{id}", order.getCustomerId())
                .retrieve()
                .bodyToMono(CustomerDTO.class)
                .doOnNext(customer -> System.out.println("Fetched customer: " + customer))
                .doOnError(e -> System.err.println("Error fetching customer: " + e.getMessage()));

        Flux<Integer> vendorIds = Flux.fromIterable(order.getItems())
                .map(Orders.OrderItem::getVendorId)
                .distinct();

        Flux<VendorDTO> vendorFlux = vendorIds.flatMap(vendorId ->
                vendorClient.get()
                        .uri("/vendors/{id}", vendorId)
                        .retrieve()
                        .bodyToMono(VendorDTO.class)
                        .doOnNext(vendor -> System.out.println("Fetched vendor: " + vendor))
                        .doOnError(e -> System.err.println("Error fetching vendor: " + e.getMessage()))
        );

        return Mono.zip(customerMono, vendorFlux.collectList())
                .flatMap(tuple -> {
                    CustomerDTO customer = tuple.getT1();
                    List<VendorDTO> vendors = tuple.getT2();

                    Mono<Void> customerEmail = customer != null
                            ? emailService.sendEmail(customer.getEmail(), "Order Confirmation", createCustomerEmailBody(order))
                            .doOnSubscribe(subscription -> System.out.println("Sending email to customer: " + customer.getEmail()))
                            : Mono.empty();

                    List<Mono<Void>> vendorEmails = vendors.stream()
                            .map(vendor -> emailService.sendEmail(vendor.getContactEmail(), "New Order Received", createVendorEmailBody(order, vendor))
                                    .doOnSubscribe(subscription -> System.out.println("Sending email to vendor: " + vendor.getContactEmail())))
                            .collect(Collectors.toList());

                    return Mono.when(customerEmail, Mono.when(vendorEmails.toArray(Mono[]::new)))
                            .doOnSuccess(aVoid -> System.out.println("All emails sent successfully"))
                            .doOnError(e -> System.err.println("Error sending emails: " + e.getMessage()));
                });
    }



    private String createCustomerEmailBody(Orders order) {
        return String.format("Dear Customer,\n\nYour order with ID %d has been placed successfully.\nTotal Amount: %.2f\nShipping Address: %s\n\nThank you for shopping with us!\n\nOrder Details:\n%s",
                order.getId(), order.getTotalAmount(), order.getShippingAddress(), formatOrderItems(order.getItems()));
    }

    private String createVendorEmailBody(Orders order, VendorDTO vendor) {
        List<Orders.OrderItem> items = order.getItems().stream()
                .filter(item -> item.getVendorId().equals(vendor.getId()))
                .collect(Collectors.toList());

        return String.format("Dear Vendor,\n\nYou have received a new order with ID %d.\n\nOrder Details:\n%s",
                order.getId(), formatOrderItems(items));
    }

    private String formatOrderItems(List<Orders.OrderItem> items) {
        return items.stream()
                .map(item -> String.format("Product ID: %d, Quantity: %d, Price: %.2f",
                        item.getProductId(), item.getQuantity(), item.getPrice()))
                .collect(Collectors.joining("\n"));
    }
}
