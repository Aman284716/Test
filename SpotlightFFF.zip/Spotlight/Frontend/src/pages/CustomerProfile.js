import React, { useEffect, useState } from "react";
import OrderCard from "../components/CustomerOrdersCard";
import Cookies from "js-cookie";
import axios from "axios";
import { toast } from "react-toastify";
import { CheckCircleIcon } from "@heroicons/react/solid";
import { useNavigate } from "react-router";

const CustomerProfile = () => {
  const [customer, setCustomer] = useState(null);
  const [orders, setOrders] = useState([]);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [updatedCustomer, setUpdatedCustomer] = useState({});
  const [selectedFile, setSelectedFile] = useState(null);
  const [imageUploaded, setImageUploaded] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const customerId = Cookies.get("id"); // Get customer ID from cookies

  useEffect(() => {
    if (customerId) {
      // Fetch customer details
      axios
        .get(`http://localhost:8888/customers/${customerId}`)
        .then((response) => {
          setCustomer(response.data);
          setUpdatedCustomer(response.data); // Set the current customer data to update form
        })
        .catch((error) => {
          console.error("Error fetching customer data:", error);
        });

      // Fetch customer orders
      axios
        .get(`http://localhost:8888/orders/customer/${customerId}`)
        .then((response) => {
          // Sort orders by orderId in descending order
          const sortedOrders = response.data.sort((a, b) => b.orderId - a.orderId);
          setOrders(sortedOrders);
        })
        .catch((error) => {
          console.error("Error fetching orders:", error);
        });
    }
  }, [customerId]);

  const handleUpdateProfile = () => {
    setIsUpdateModalOpen(true); // Open the modal
  };

  const handleModalClose = () => {
    setIsUpdateModalOpen(false); // Close the modal
  };

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    setUpdatedCustomer({
      ...updatedCustomer,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formDataForImage = new FormData();
    formDataForImage.append("file", file);
    formDataForImage.append("upload_preset", "ymsskzwa"); // Replace with your upload preset
    formDataForImage.append("cloud_name", "dzm3qqhtc"); // Replace with your Cloudinary cloud name

    try {
      const response = await fetch(
        "https://api.cloudinary.com/v1_1/dzm3qqhtc/image/upload",
        {
          method: "POST",
          body: formDataForImage
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }

      const result = await response.json();
      const imageUrl = result.secure_url;

      setUpdatedCustomer({
        ...updatedCustomer,
        profileImageUrl: imageUrl
      });

      setImageUploaded(true);
    } catch (error) {
      console.error("Error:", error);
      setError("There was a problem with the image upload.");
    }
  };

  const handleSaveChanges = async () => {
    if (selectedFile) {
      const imageUrl = await uploadToCloudinary(selectedFile);
      if (imageUrl) {
        setUpdatedCustomer({
          ...updatedCustomer,
          profileImageUrl: imageUrl
        });
      }
    }

    axios
      .put(`http://localhost:8081/customers/${customerId}`, updatedCustomer)
      .then((response) => {
        setCustomer(response.data); // Update the UI with new customer data
        setIsUpdateModalOpen(false); // Close the modal after updating
        toast.success("Profile updated successfully!");
        setImageUploaded(false);
        setTimeout(() => setSuccess(""), 2000);
      })
      .catch((error) => {
        console.error("Error updating customer profile:", error);
        setError(
          error.response?.data?.message ||
          "Error updating profile. Please try again."
        );
      });
  };

  const uploadToCloudinary = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', 'ymsskzwa'); // Replace with your upload preset

    try {
      const response = await axios.post(
        'https://api.cloudinary.com/v1_1/dzm3qqhtc/image/upload',
        formData
      );
      return response.data.secure_url;
    } catch (error) {
      console.error("Error uploading to Cloudinary:", error);
      return null;
    }
  };

  const handleDeleteProfile = async () => {
    if (window.confirm("Are you sure you want to delete your profile? This action cannot be undone.")) {
      try {
        await axios.delete(`http://localhost:8081/customers/${customerId}`);
        // Clear cookies
        Cookies.remove("id");
        toast.success("Profile deleted successfully!");
        setCustomer(null); // Clear customer data from the UI
        // Redirect to login page
        navigate("/login");
      } catch (error) {
        console.error("Error deleting customer profile:", error);
        toast.error("Error deleting profile. Please try again.");
      }
    }
  };

  if (!customer) {
    return <p>Loading...</p>;
  }

  return (
    <div className="container mx-auto p-6 bg-gray-100 rounded-lg shadow-md">
      {/* Customer Details Section */}
      <div className="flex items-center mb-8">
        <img
          src={customer.profileImageUrl}
          alt={`${customer.firstName} ${customer.lastName}`}
          className="w-48 h-48 rounded-full m-6 shadow-lg border-2 border-orange-400"
        />
        <div>
          <h2 className="text-2xl font-bold text-gray-800">
            {customer.firstName} {customer.lastName}
          </h2>
          <p className="text-gray-600">Email: {customer.email}</p>
          <p className="text-gray-600">Phone: {customer.phoneNumber}</p>
          <p className="text-gray-600">Address: {customer.address}</p>
          <div className="mt-4">
            <button
              onClick={handleUpdateProfile}
              className="mr-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Update Profile
            </button>
            <button
              onClick={handleDeleteProfile}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Delete Profile
            </button>
          </div>
        </div>
      </div>

      {/* Orders Section */}
      <h3 className="text-xl font-semibold text-gray-800 mb-4">My Orders</h3>
      <div className="space-y-4">
        {orders.length > 0 ? (
          orders.map((order) => <OrderCard key={order.id} order={order} />)
        ) : (
          <p className="text-gray-700">No orders found.</p>
        )}
      </div>

      {/* Update Modal */}
      {isUpdateModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
            <h3 className="text-2xl font-bold mb-4">Update Profile</h3>
            <div className="space-y-4">
              <input
                type="text"
                name="username"
                value={updatedCustomer.username}
                onChange={handleInputChange}
                placeholder="Username"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="email"
                name="email"
                value={updatedCustomer.email}
                onChange={handleInputChange}
                placeholder="Email"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                name="phoneNumber"
                value={updatedCustomer.phoneNumber}
                onChange={handleInputChange}
                placeholder="Phone Number"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                name="address"
                value={updatedCustomer.address}
                onChange={handleInputChange}
                placeholder="Address"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                name="firstName"
                value={updatedCustomer.firstName}
                onChange={handleInputChange}
                placeholder="First Name"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="text"
                name="lastName"
                value={updatedCustomer.lastName}
                onChange={handleInputChange}
                placeholder="Last Name"
                className="w-full px-4 py-2 border rounded-lg"
              />
              <input
                type="file"
                name="profileImage"
                className="w-full px-4 py-2 border rounded-lg"
                onChange={handleFileChange}
              />
              {imageUploaded && (
                <div className="mt-2 text-green-500">
                  <CheckCircleIcon className="h-5 w-5 inline-block" /> Image
                  uploaded successfully!
                </div>
              )}
            </div>
            <div className="mt-6 flex justify-end space-x-4">
              <button
                onClick={handleModalClose}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveChanges}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerProfile;
