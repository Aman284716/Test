package com.example.Orders.service;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public Mono<Void> sendEmail(String to, String subject, String text) {
        return Mono.fromRunnable(() -> {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            try {
                System.out.printf("Sending email to: %s\nSubject: %s\nBody:\n%s\n", to, subject, text);
                mailSender.send(message);
                System.out.println("Email sent successfully!");
            } catch (MailException e) {
                System.err.println("Failed to send email: " + e.getMessage());
                throw new RuntimeException("Failed to send email", e);
            }
        });
    }
}
