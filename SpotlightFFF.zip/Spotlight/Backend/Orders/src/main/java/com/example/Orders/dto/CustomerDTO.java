package com.example.Orders.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CustomerDTO {
    private Integer id;
    private String username;
    private String email;
}