package com.example.Discovery_Eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
